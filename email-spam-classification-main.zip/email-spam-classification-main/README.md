# email-spam-classification
A project aimed at classifying emails as spam or ham. CountVectorizer was used for vectorization and Random Forest Classifier to classify text. GridSearchCV - for hyper-parameter tuning. Model accuracy of 97% was achieved.
